import Foundation

class Configs {
    static let tableViewMessagesID = "tableViewMessagesID"
}
